package assetmanagement;

import java.util.ArrayList;
import java.sql.*;
import java.math.BigDecimal;

public class assetrental {
    String connURL = "jdbc:mysql://localhost:3306/HOADB?useTimezone=true&serverTimezone=UTC&user=root&password=12345678";
    
    String query; // used for storing string SQL queries
    PreparedStatement statement; // used for storing prepared statements
    ResultSet result; // used for storing SQL query results
    
    public int asset_id;
    public Date rental_date;
    public Date reservation_date;
    public int resident_id;
    public int trans_hoid;
    public String trans_position;
    public Date trans_electiondate;
    public BigDecimal rental_amount;
    public BigDecimal discount;
    
    public ArrayList<Integer> asset_idList  = new ArrayList<>();

    
    public int rentAsset() {
        try {
            // Step 0: Connect to DB
            Connection conn;
            conn = DriverManager.getConnection(connURL);
            System.out.println("Renting assets connection successful");
            
            // Step 1: Set resident to being a renter.
            /*query = "UPDATE residents SET renter = 1 WHERE resident_id = ?";
            statement = conn.prepareStatement(query);
            statement.setInt(1, resident_id);
            statement.executeUpdate();*/
            
            // Step 2: Put all asset ids to list which will all be set to being
            // rented and have a rental and transaction entry created for.
            asset_idList.clear();
            asset_idList.add(asset_id); // main asset being rented
            
            query = "SELECT asset_id FROM assets WHERE enclosing_asset = ? AND enclosing_asset NOT IN (SELECT ar.asset_id from asset_rentals ar JOIN asset_transactions at ON ar.asset_id = at.asset_id AND ar.rental_date = at.transaction_date WHERE at.isdeleted = 0 AND ar.status IN ('O', 'R'));"; // ensure asset is not On rent/Reserved
            statement = conn.prepareStatement(query);
            statement.setInt(1, asset_id);
            result = statement.executeQuery();
            
            while (result.next()) {
                int assetID = result.getInt("asset_id");
                asset_idList.add(assetID);
            }
            
            // Step 3: Get next OR number.
            query = "SELECT MAX(ornum) + 1 AS ornum FROM ref_ornumbers";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
            
            int nextOrnum = 1; // if no records yet, default is 1
            while (result.next()) {
                nextOrnum = result.getInt("ornum");
            }

            query = "INSERT INTO ref_ornumbers (ornum) VALUE(?)";
            statement = conn.prepareStatement(query);
            statement.setInt(1, nextOrnum);
            statement.executeUpdate();
            
            // Step 4: For all asset ids in the list, set all to be rented
            // and generate a rental and transaction entry.
            // Only one "depth" of child assets are done. For more "depths",
            // look into recursive SQL statements or graph algorithms.
            for (int id : asset_idList) {
                // Set asset to rented
                /*query = "UPDATE assets SET forrent = 0 WHERE assetid = ?";
                statement = conn.prepareStatement(query);
                statement.setInt(1, id);
                statement.executeUpdate();*/
                
                // Create new OR number reference for asset
                // Commented out, let them share an OR num
                /*query = "INSERT INTO ref_ornumbers (ornum) VALUE(?)";
                statement = conn.prepareStatement(query);
                statement.setInt(1, nextOrnum);
                statement.executeUpdate();*/
                
                // Create transaction for asset
                query = "INSERT INTO asset_transactions (asset_id, transaction_date, "
                    + "trans_hoid, trans_position, trans_electiondate, isdeleted, "
                    + "ornum, transaction_type )"
                    + "VALUE (?, ?, ?, ?, ?, ?, ?, ?)";
                statement = conn.prepareStatement(query);
                statement.setInt(1, asset_id);
                statement.setDate(2, rental_date);
                statement.setInt(3, trans_hoid);
                statement.setString(4, trans_position);
                statement.setDate(5, trans_electiondate);
                statement.setInt(6, 0); // not deleted
                statement.setInt(7, nextOrnum);
                statement.setString(8, "R"); // R for rental
                statement.executeUpdate();
                
                // Create rental for asset
                query = "INSERT INTO asset_rentals (asset_id, rental_date, "
                    + "reservation_date, resident_id, rental_amount, discount, "
                    + "status) "
                    + "VALUES(?, ?, ?, ?, ?, ?, ?)";
                statement = conn.prepareStatement(query);
                statement.setInt(1, asset_id);
                statement.setDate(2, rental_date);
                statement.setDate(3, reservation_date);
                statement.setInt(4, resident_id);
                statement.setBigDecimal(5, rental_amount);
                statement.setBigDecimal(6, discount);
                statement.setString(7, "O"); // O for On Rent
                statement.executeUpdate();
                
                //nextOrnum += 1; // generate a new OR number for each asset
            }
                        
            statement.close();
            conn.close();
            System.out.println("Asset rental successful");
            return 1;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Renting assets connection failed");
            return 0;
        }
    }
}
